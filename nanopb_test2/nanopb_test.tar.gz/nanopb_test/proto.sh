MYDIR=`pwd`
PROTO_PATH=$MYDIR/../nanopb
echo $PROTO_PATH
protoc --proto_path=$MYDIR --nanopb_out=$MYDIR dmessage.proto